package com.example.mcauto

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button

class ClickerService : AccessibilityService() {

    // ===== НАЛАШТУВАННЯ (частки екрана 0.0–1.0, підлаштуй під свій HUD) =====
    private val joyX = 0.15f; private val joyY = 0.75f; private val joyForwardY = 0.55f // джойстик: вперед
    private val camStartX = 0.60f; private val camY = 0.40f; private val camSpan = 0.15f // камера: рух екрана
    private val atkX = 0.88f; private val atkY = 0.50f                                  // кнопка копання/удару
    private val cycleMs = 650L                                                           // довжина одного циклу
    private val tapMs = 25L                                                              // тривалість одного тапу
    // 9 тапів за 0.65 с ≈ 12–13 тапів/с (Android дозволяє макс. 10 дотиків за один жест)
    private val moveForward = true; private val clicking = true
    private var moveCamera = false   // вмикається кнопкою CAM на екрані
    // =======================================================================

    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var dir = 1
    private lateinit var btn: Button
    private lateinit var camBtn: Button
    private lateinit var wm: WindowManager

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        btn = Button(this).apply {
            text = "▶ ON"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#AA2E7D32"))
            setOnClickListener { toggle() }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 20 }
        wm.addView(btn, lp)

        camBtn = Button(this).apply {
            text = "CAM: OFF"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#AA555555"))
            setOnClickListener {
                moveCamera = !moveCamera
                text = if (moveCamera) "CAM: ON" else "CAM: OFF"
                setBackgroundColor(Color.parseColor(if (moveCamera) "#AA1565C0" else "#AA555555"))
            }
        }
        val lp2 = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 170 }
        wm.addView(camBtn, lp2)
    }

    private fun toggle() {
        running = !running
        btn.text = if (running) "■ OFF" else "▶ ON"
        btn.setBackgroundColor(Color.parseColor(if (running) "#AAC62828" else "#AA2E7D32"))
        if (running) cycle() else handler.removeCallbacksAndMessages(null)
    }

    private fun cycle() {
        if (!running) return
        val w = resources.displayMetrics.widthPixels.toFloat()
        val h = resources.displayMetrics.heightPixels.toFloat()
        val b = GestureDescription.Builder()

        if (moveForward) {
            // торкаємось одразу в позиції "вперед", щоб джойстик не гальмував на початку циклу
            val p = Path().apply { moveTo(w * joyX, h * joyForwardY); lineTo(w * joyX, h * joyForwardY - 2) }
            b.addStroke(GestureDescription.StrokeDescription(p, 0, cycleMs))
        }
        if (moveCamera) {
            val p = Path().apply {
                moveTo(w * camStartX, h * camY)
                lineTo(w * (camStartX + dir * camSpan), h * camY)
            }
            b.addStroke(GestureDescription.StrokeDescription(p, 0, cycleMs))
            dir = -dir
        }
        if (clicking) {
            val maxTaps = if (moveForward && moveCamera) 8 else if (moveForward || moveCamera) 9 else 10
            val step = cycleMs / maxTaps
            for (i in 0 until maxTaps) {
                val p = Path().apply { moveTo(w * atkX, h * atkY) }
                b.addStroke(GestureDescription.StrokeDescription(p, i * step, tapMs))
            }
        }

        val ok = dispatchGesture(b.build(), object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { next(0) }
            override fun onCancelled(g: GestureDescription?) { next(200) }
        }, null)
        if (!ok) next(500)
    }

    private fun next(delay: Long) { if (running) handler.postDelayed({ cycle() }, delay) }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { running = false; handler.removeCallbacksAndMessages(null) }
    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        if (::btn.isInitialized) wm.removeView(btn)
        if (::camBtn.isInitialized) wm.removeView(camBtn)
        super.onDestroy()
    }
}
