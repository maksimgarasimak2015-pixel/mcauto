package com.example.mcauto

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button

class ClickerService : AccessibilityService() {

    // ===== НАЛАШТУВАННЯ (частки екрана 0.0–1.0, підлаштуй під свій HUD) =====
    private val joyX = 0.15f; private val joyY = 0.75f; private val joyForwardY = 0.55f // джойстик: вперед
    private val camStartX = 0.60f; private val camY = 0.40f; private val camSpan = 0.15f // камера: рух екрана
    private val atkX = 0.88f; private val atkY = 0.50f                                  // кнопка копання/удару
    private val cycleMs = 4000L                                                          // довжина одного циклу
    private val moveForward = true; private val moveCamera = true; private val hold = true
    // =======================================================================

    private val handler = Handler(Looper.getMainLooper())
    private var running = false
    private var dir = 1
    private lateinit var btn: Button
    private lateinit var wm: WindowManager

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        btn = Button(this).apply {
            text = "▶ ON"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#AA2E7D32"))
            setOnClickListener { toggle() }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 20 }
        wm.addView(btn, lp)
    }

    private fun toggle() {
        running = !running
        btn.text = if (running) "■ OFF" else "▶ ON"
        btn.setBackgroundColor(Color.parseColor(if (running) "#AAC62828" else "#AA2E7D32"))
        if (running) cycle() else handler.removeCallbacksAndMessages(null)
    }

    private fun cycle() {
        if (!running) return
        val w = resources.displayMetrics.widthPixels.toFloat()
        val h = resources.displayMetrics.heightPixels.toFloat()
        val b = GestureDescription.Builder()

        if (moveForward) {
            val p = Path().apply { moveTo(w * joyX, h * joyY); lineTo(w * joyX, h * joyForwardY) }
            b.addStroke(GestureDescription.StrokeDescription(p, 0, cycleMs))
        }
        if (moveCamera) {
            val p = Path().apply {
                moveTo(w * camStartX, h * camY)
                lineTo(w * (camStartX + dir * camSpan), h * camY)
            }
            b.addStroke(GestureDescription.StrokeDescription(p, 0, cycleMs))
            dir = -dir
        }
        if (hold) {
            val p = Path().apply { moveTo(w * atkX, h * atkY); lineTo(w * atkX + 1, h * atkY) }
            b.addStroke(GestureDescription.StrokeDescription(p, 0, cycleMs))
        }

        val ok = dispatchGesture(b.build(), object : GestureResultCallback() {
            override fun onCompleted(g: GestureDescription?) { next(30) }
            override fun onCancelled(g: GestureDescription?) { next(200) }
        }, null)
        if (!ok) next(500)
    }

    private fun next(delay: Long) { if (running) handler.postDelayed({ cycle() }, delay) }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { running = false; handler.removeCallbacksAndMessages(null) }
    override fun onDestroy() {
        running = false
        handler.removeCallbacksAndMessages(null)
        if (::btn.isInitialized) wm.removeView(btn)
        super.onDestroy()
    }
}
