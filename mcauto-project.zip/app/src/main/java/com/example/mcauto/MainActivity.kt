package com.example.mcauto

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 96, 48, 48) }
        root.addView(TextView(this).apply {
            text = "1. Натисни кнопку нижче\n2. Спеціальні можливості → MC Auto → увімкни\n3. Відкрий Minecraft: зверху з'явиться кнопка ▶ ON / ■ OFF"
            textSize = 16f
        })
        root.addView(Button(this).apply {
            text = "Відкрити налаштування"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        setContentView(root)
    }
}
